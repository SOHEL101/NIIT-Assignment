const express = require('express');
const app = express();
const path = require('path');
var mongo = require('mongodb');
const bodyParser = require('body-parser');
var mongojs = require('mongojs');
var methodOverride = require('method-override');
var bson = require('bson');
var Promise = require('es6-promise').Promise;
app.use(bodyParser.json({
	limit: '50mb'
})); // parse application/json
app.use(bodyParser.json({
	type: 'application/vnd.api+json'
})); // parse application/vnd.api+json as json
app.use(bodyParser.urlencoded({
	limit: '50mb',
	extended: true,
	parameterLimit: 50000
})); // parse application/x-www-form-urlencoded
app.use(bodyParser.json());
app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
	next();
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));
var db = mongojs('CustomerComplaintForumDB')
db.loginDetails.insert({})
app.post('/loginDetails', function(req, res) {
	db.loginDetails.find({
		"userEmail": req.body.userEmail
	}, function(err, doc) {
		console.log(doc.length)
		if(doc.length === 0) {
			db.loginDetails.insert(req.body, function(err, data) {
				res.json(data);
			});
		} else {
			res.json(doc);
		}
	})
})
app.post('/complaintDetails', function(req, res) {
	db.complaintDetails.insert(req.body, function(err, doc) {
		res.json(doc);
	});
})
app.get('/getHeaderComplaint:data', function(req, res) {
	db.complaintDetails.find({
		"heading": req.params.data
	}, function(err, doc) {
		res.json(doc);
	})
})
app.get('/getComplaintDetails:data', function(req, res) {
	db.loginDetails.find({
		"userEmail": req.params.data
	}, function(err, doc) {
		console.log(doc)
		if(doc.length == 0) {} else if(doc[0].accountType === 'Agent') {
			db.complaintDetails.find({}).sort({
				_id: -1
			}, function(err, agent) {
				res.json(agent);
			})
		} else {
			db.complaintDetails.find({
				"email": req.params.data
			}).sort({
				_id: -1
			}, function(err, customer) {
				res.json(customer);
			})
		}
	})
})
app.put('/updateCustomerStatus', function(req, res) {
	db.complaintDetails.update({
		"heading": req.body.heading
	}, {
		$set: {
			"status": req.body.status,
			"dateUpdated": req.body.dateUpdated,
			"comments": req.body.comments
		}
	}, function(err, doc) {
		res.json(doc)
	})
})
const port = 2111;
app.listen(port, function() {
	console.log("server running on port" + port);
});