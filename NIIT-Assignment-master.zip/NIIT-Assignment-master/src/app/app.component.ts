

import { Component,OnInit } from '@angular/core';
import {  RouterModule, Routes   } from '@angular/router';

import { Router } from '@angular/router'; 
import { Location } from '@angular/common';
import { Directive } from '@angular/core';


// export const appRoutes: Routes = [
//   { path: '', component: LoginComponent },
//    { path: 'projectDetail', component: ProjectDetailComponent  },
//  { path: 'projectSelection', component: SelectionComponent  },
//   { path: 'ImportPage', component: ImportComponent },
  
// ];
@Component({
  selector: 'app-root',
 
   templateUrl:'./app.component.html',
            
           
 // providers: [LoginServiceComponent],

         })//componrnt  closing

export class AppComponent implements OnInit{
  

  constructor(){
  



}


ngOnInit(){


}



}
