import { Component, OnInit } from '@angular/core';
import { Http,Response } from '@angular/http';
import { URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-complaints',
  templateUrl: './complaints.component.html',
  styleUrls: ['./complaints.component.css']
})
export class ComplaintsComponent implements OnInit {
	userData = []
	userEmail: string;
	accountType: string;
	constructor(private http: Http, private router: Router) {}
	ngOnInit() {
		this.userEmail = sessionStorage.getItem('userEmail');
		this.accountType = sessionStorage.getItem('accountType');
		this.showComplaintTable()
		if(this.accountType == 'Customer') {
			document.getElementById("widthTable").style.width = "70%";
		} else {
			document.getElementById("widthTable").setAttribute("style", " width:90%;top:-10%;margin-left:2%");
		}
	}
	dateUpdated: string;
	updateCustomerDetails = []
	status: string
	comments: string
	customerStatus(status, comments) {
		console.log(comments)
		this.dateUpdated = new Date().toLocaleString();
		let urlSearchParams = new URLSearchParams();
		urlSearchParams.append('heading', this.userHeading);
		urlSearchParams.append('dateUpdated', this.dateUpdated);
		urlSearchParams.append('status', status);
		urlSearchParams.append('comments', comments);
		return this.http.put('http://localhost:2111/updateCustomerStatus', urlSearchParams).map(response => response.json()).subscribe(data => {
			this.showComplaintTable()
		});
	}
	showComplaintTable() {
		if(this.userEmail == null) {
			this.router.navigate(['']);
		} else {
			this.http.get('http://localhost:2111/getComplaintDetails' + this.userEmail).map((response: Response) => response.json()).subscribe(result => {
				this.userData = result;
				this.showUserStatus(this.userData)
				console.log(this.userData);
			});
		}
	}
	selectedUserDateCreated: string
	selectedUserDateUpdated: string
	noComplaints: string
	selectedDescription: string
	selectedHeading: string
	showUserStatus(userData) {
		console.log(userData)
		if(userData.length === 0) {
			this.noComplaints = 'Currently They Are No Complaints'
		}
	}
	userHeading: string
	displaySelectedHeaderDetails = []
	selectedUserHeading(heading) {
		this.userHeading = heading
			//console.log(heading)
		this.http.get('http://localhost:2111/getHeaderComplaint' + heading).map((response: Response) => response.json()).subscribe(result => {
			this.displaySelectedHeaderDetails = result;
			this.selectedUserDateCreated = this.displaySelectedHeaderDetails[0].dateCreated;
			this.selectedUserDateUpdated = this.displaySelectedHeaderDetails[0].dateUpdated;
			this.selectedDescription = this.displaySelectedHeaderDetails[0].description;
			this.selectedHeading = this.displaySelectedHeaderDetails[0].heading;
			this.status = this.displaySelectedHeaderDetails[0].status;
			this.comments = this.displaySelectedHeaderDetails[0].comments;
		});
	}
	showList() {
		this.showComplaintList = true
	}
	description: string;
	heading: string
	dateCreated: string
	showComplaintList = false
	savecomplient(heading, description) {
		this.noComplaints = undefined
		console.log(description)
		console.log(heading)
		this.dateCreated = new Date().toLocaleString();
		if(this.heading == undefined || this.description == undefined) {
			alert("Please Fill Mandatory Fields")
		} else {
			let urlSearchParams = new URLSearchParams();
			urlSearchParams.append('heading', heading);
			urlSearchParams.append('description', description);
			urlSearchParams.append('email', this.userEmail);
			urlSearchParams.append('dateCreated', this.dateCreated);
			this.heading = '';
			this.description = ''
			return this.http.post('http://localhost:2111/complaintDetails', urlSearchParams).map(response => response.json()).subscribe(data => {
				data;
				console.log(data);
				console.log("enterrr");
				this.showComplaintTable()
			});
		}
	}
	signOutFun() {
		this.router.navigate(['']);
	}
}