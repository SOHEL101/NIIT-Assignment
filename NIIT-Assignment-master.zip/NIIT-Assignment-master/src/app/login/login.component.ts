import { Component, OnInit } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs';
import { URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/map';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	constructor(private http: Http, private router: Router) {}
	ngOnInit() {}
	passwordDetails: string;
	numberDetails: number;
	userEmail: string
	accountType: string;
	checkLoginDetails(userEmail, numberDetails, passwordDetails, accountType) {
		console.log(userEmail)
		console.log(numberDetails)
		console.log(passwordDetails)
		console.log(accountType)
		if(userEmail == undefined || numberDetails == undefined || passwordDetails == undefined || accountType == undefined) {
			alert("Please Fill Mandatory Fields")
		} else {
			let urlSearchParams = new URLSearchParams();
			urlSearchParams.append('userEmail', userEmail);
			urlSearchParams.append('numberDetails', numberDetails);
			urlSearchParams.append('passwordDetails', passwordDetails);
			urlSearchParams.append('accountType', accountType);
			this.passwordDetails = '';
			this.numberDetails = null;
			this.accountType = ''
			this.userEmail = ''
			this.accountType = ''
			sessionStorage.setItem('userEmail', userEmail);
			sessionStorage.setItem('accountType', accountType);
			this.router.navigate(['/complaint']);
			return this.http.post('http://localhost:2111/loginDetails', urlSearchParams).map(response => response.json()).subscribe(data => {
				data;
				console.log(data)
			});
		}
	}
}
