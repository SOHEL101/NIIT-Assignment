import {BrowserModule} from '@angular/platform-browser';
import {
  NgModule
}
from '@angular/core';
import {
  Router
}
from '@angular/router';
import {
  RouterModule, Routes
}
from '@angular/router';

import {
  FormsModule
}

from '@angular/forms';
import { HttpModule } from '@angular/http';
import {
  AppComponent
}
from './app.component';


import { LoginComponent } from './login/login.component'
import { ComplaintsComponent } from './complaints/complaints.component'

const appRoutes: Routes = [

  {
      path: '',
      component: LoginComponent
  },
  {
    path: 'complaint', component:ComplaintsComponent,
   
  
},

];


@NgModule({
  imports: [
      BrowserModule, RouterModule.forRoot(appRoutes), FormsModule,HttpModule,
  ],
  declarations: [

     AppComponent,LoginComponent,ComplaintsComponent
  ],



  bootstrap: [AppComponent]
})
export class AppModule {}