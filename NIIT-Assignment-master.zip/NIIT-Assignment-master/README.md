Steps to follow to run the project.
1.npm install or npm i (inside of) NIIT-Assignment/
2.If mongodb is installed locally in your pc (skip this step)
2.ng serve or npm run start
3.node server.js or nodemon server.js
4.use http://localhost:4200 in browser.

First, thanks for giving this opportunity.Actually i want to use services,selector,lazy module etc and also myself i identified some bugs.
Due to shortage of time available to me, i could'nt do these things.However, these are the bugs i identified.
1.When you click login button in login page.It will check the condition based on Email.It wont check remaining fields.
2.Comments sharing between customer and agent is not up to mark.
3.Sometimes when u click login button message('Currently They Are No Complaints') wont show until refresh the page.
4.When you click login button, complaint page will open and go back using up arrow data is showing.


Thanks and Regards,
Sohel
